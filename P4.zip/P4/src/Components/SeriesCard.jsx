export const SeriesCard = ({currElement}) => {
    const {img_url,name,rating,description,genre,cast} = currElement;
    return(
        <li>
            <div>
                <img src={img_url} height="40%" width="40%"/>
            </div>
            <h2>Name : {name}</h2>
            <h3>Rating : {rating}</h3>
            <p>Summary : {description}</p>
            <p>Genre : {genre}</p>
            <p>Cast : {cast}</p>
        </li>
    )
}
