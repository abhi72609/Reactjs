// import JSXasProps from "./Components/JSXasProps"
import NetflixSeries from "./Components/NetflixSeries";
import "./Components/NetflixStyle.css"
export const App = () => {
    // return <JSXasProps />;  
    // Lecture - #17 add css to react.js
    return(
        <section className="container">
            <h1 className="card-heading"> List of Best Web series On Netflix</h1>
            <NetflixSeries />
        </section>
    );
};